const db = require("../models");

const Graph  = db.graph;

const Op = db.Sequelize.Op;

const createNewGraph = async (req,res) => {
    const data = req.body
    try {
      const title = data.title
      const source = data.source
      // validate inputs 
      if (title === undefined || source == undefined) {
        throw new Error("Invalid Title or Source")
      }
      const graph = await Graph.create({ title: title, source: source});
      res.status(200).json({
        status: "success"
      });
      return
    } catch(e) {
      res.status(400).json({
        status: "Fail",
        message: e.message
      })
      return
    }  
}

const getAllGraphs = async (req,res) => {

  try {
    // validate inputs 
    const graphs = await Graph.findAll();
    res.status(200).json({
      "norp_graphs": graphs
    });
    return
  } catch(e) {
    res.status(400).json({
      status: "Fail",
      message: e.message
    })
    return
  } 
  
}

// need to check error
// deletes graph by Id
const deleteGraph = async (req,res) => {
  const data = req.body
  try {
    const id = data.id
    // validate inputs 
    if (id === undefined) {
      throw new Error("Invalid Id")
    }
    await Graph.destroy({where: {id: id}});
    res.status(200).json({
      status: "success"
    });
    return
  } catch(e) {
    res.status(400).json({
      status: "Fail",
      message: e.message
    })
    return
  } 
}

// update graph
const editGraph = async (req,res) => {
  const data = req.body
  try {
    const id = data.id
    const title = data.title
    const source = data.source
    // validate inputs 
    if (id === undefined || title === undefined || source == undefined) {
      throw new Error("Invalid Title or Source")
    }
    const graph = await Graph.findOne({where: {id: id}});
    graph.title = title
    graph.source = source
    await graph.save();
    res.status(200).json({
      status: "success"
    });
    return
  } catch(e) {
    res.status(400).json({
      status: "Fail",
      message: e.message
    })
    return
  }  
}

module.exports = {
  createNewGraph,
  getAllGraphs,
  deleteGraph,
  editGraph
}