const express = require('express')

const router = express.Router()

router.get('/', (req,res) => {
    res.send('<h1>Hi! Welcome to the Dummy page</h1><br><form  action="/login" method="post">Username:<input id="username" name="username" type="text"/><br>Password:<input id="password" name="password" type="text"/><br><input type="submit"/></form><br><a href="/auth/google">Click here to Login with Google</a>')
});

module.exports = router