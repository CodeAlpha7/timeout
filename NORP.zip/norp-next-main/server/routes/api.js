const express = require('express')
const router = express.Router()

const videosController = require('../controllers/videoController')
const graphsController = require('../controllers/graphController')
const publicationController = require('../controllers/publicationController')
const peopleController = require('../controllers/peopleController')
const userController = require('../controllers/userController')


/**
 * end point: /api/video
 */
router.route('/video')
  .get(videosController.getAllVideos)
  .post(videosController.createNewVideo)
  .delete(videosController.deleteVideo)
  .put(videosController.editVideo)

/**
 * end point: /api/graphs
 */
router.route('/graph')
  .get(graphsController.getAllGraphs)
  .post(graphsController.createNewGraph)
  .delete(graphsController.deleteGraph)
  .put(graphsController.editGraph)



/**
 * end point: /api/pub
 */
router.route('/pub')
    .get(publicationController.getAllPublication)
    .post(publicationController.createNewPublication)
    .delete(publicationController.deletePublication)
    .put(publicationController.editPublication)


/**
 * end point: /api/people
 */
router.route('/people')
 .get(peopleController.getAllPeople)
 .post(peopleController.createNewPerson)
 .delete(peopleController.deletePerson)
 .put(peopleController.editPerson)


/**
 * (Authenticated)
 * end point: /api/user
 */
router.route('/user')
 .get(userController.getUser)
 .post(userController.createNewUser)
 .delete(userController.deleteUser)
 .put(userController.updateUser)


module.exports = router


