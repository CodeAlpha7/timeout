const express = require('express')
const router = express.Router()

const passport = require('passport')

const generatePassword = require('../utils/encrypt').generatePassword;


// process get request on /
// router.post('/login', passport.authenticate('local'), (req,res) => {
//     const { username, password } = req.body;
//     req.session.authenticated = true;
//     req.session.user = { username, password };
//     res.cookie(`username=${username}; secure; httponly;`);  // Expires in one month
//     res.status(200).send({username});
// });

// module.exports = router

router.post('/login', passport.authenticate('local'), (req,res) => {
    const { username, password } = req.body;
    const { salt, hash } = generatePassword(password);
    req.session.authenticated = true;
    req.session.user = { username, hash, salt};
    res.status(200).send({username});
});

module.exports = router