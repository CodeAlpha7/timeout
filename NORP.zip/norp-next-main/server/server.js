// imported libraries
const express = require('express')
const helmet = require('helmet')
const next = require('next')
const session = require('express-session')
const dotenv = require('dotenv')

// Authentication
const passport = require('passport');
const localStr = require('./strategies/local');
const googleStr = require('./strategies/google_oauth');
const ser = require('./strategies/serialize');

const http = require('http')
const cookie = require('cookie')
// precaution against denial of service
const toobusy = require('toobusy-js');

dotenv.config()

// create the database 
const db = require("./models");

db.sequelize.sync().then(()=> console.log("db ready"));

var logger = require('morgan');
const { send } = require('process');

const dev = process.env.NODE_ENV !== 'production';
const app = next({ dev });
const handle = app.getRequestHandler();


app.prepare().then(() => {
    const server = express()
    // frontend sends data in "application/json" or "application/x-www-form-urlencoded"

    // Denial of Service
    // if overwhelm, sends 503 server too busy
    // server.use(function(req, res, next) {
    //     if (toobusy()) {
    //         // log if you see necessary
    //         res.send(503, "Server Too Busy");
    //     } else {
    //     next();
    //     }
    // });

    function isLoggedIn(req, res, next) {
        if(req.user) {
            cookies = cookie.parse(req.headers.cookie || '') 
            if(cookies["metabase.SESSION"]){
                next()
            }
            else{
                const idToken = req.user.auth_id_token
                const data = JSON.stringify({
                    token: idToken,
                });
                var options = {
                    host: 'localhost',
                    port : 3000,
                    method: 'POST',
                path: '/api/session/google_auth',
                headers: {
                    'Content-Type': 'application/json',
                    'Content-Length': data.length,
                },
            };
            
            const callback = function(response) {
                var str = '';
                //another chunk of data has been received, so append it to `str`
                response.on('data', function (chunk) {
                    str += chunk;
                })
                
                response.on('end', function () {
                    if (response.statusCode === 200) {
                        const jsonVal = JSON.parse(str);
                        const metabaseSession = jsonVal["id"]
                        res.setHeader('Set-Cookie', cookie.serialize('metabase.SESSION', metabaseSession, {path: '/', httpOnly: true}));
                    }
                    next()  
                });
            };
            // request function is async 
                const reqes = http.request(options, callback);
                reqes.on('error', function(error) {
                    // metabase is not reachable
                    next()
                });
                reqes.write(data);
                reqes.end();
            } 
        }
        else{
            res.sendStatus(401);  
        } 
      }
    
    server.use(express.urlencoded({ extended: true, limit: "1kb" })); // add request size limit
    server.use(express.json({limit: "1kb"})) // add request size limit

    // needed for passport 
    server.use(session({secret: 'anything', resave: false, cookie: {maxAge: 100000}, saveUninitialized: false }));

    // login
    server.use(passport.initialize());
    server.use(passport.session());
    // server.use('/auth', authRoute);

    
    // registration path
    server.post('/reg',require('./routes/reg'))
    
    // login path
    server.post('/login',require('./routes/login'))

    
    //google auth
    server.get('/auth/google',require('./routes/google'))
    server.get('/auth/google/callback',require('./routes/google'))
    server.get('/auth/google/failure',require('./routes/google'))
    server.get('/logout',isLoggedIn, require('./routes/logout'))
    
    server.get('/protected', isLoggedIn, (req, res) => {
        //res.send(`Hello ${req.user.displayName} <br> <a href="http://localhost:3000">Click here to go to metabase</a>`);
        res.redirect('/');
    });
    
    // dummy path 
    // server.use('/dummy',require('./routes/dummy'))

    server.get('/authuser', (req, res) => {
        if(req.user) {
            res.json(req.user.username)
        }
        else{
            res.sendStatus(401);  
        } 
    });    
    
    // api path 
    server.use('/api',isLoggedIn, require('./routes/api'))
    
    // all the routes not defined in express will be handled by nextjs
    server.all("*/*", (req, res) => {
        return handle(req, res);
    });
    
    server.use(helmet())
    // define PORT
    const PORT = process.env.PORT || 5000
    // https
    //   .createServer({
    // 	key: fs.readFileSync("./server/norp.key"),
    // 	cert: fs.readFileSync("./server/norp.crt"),
    //   },app)
    //   .listen(PORT, ()=>{
    // 	console.log(`Server running at port ${PORT}`);
    // });

    // start server 
    server.listen(PORT, ()=>{
        console.log(`Server running at http://localhost:${PORT}`);
    }); 
});


