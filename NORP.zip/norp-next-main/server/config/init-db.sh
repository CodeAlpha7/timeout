#!/bin/bash

set -e

echo "Install Libraries"
apt update && apt install -y jq sed mariadb-client

echo "Get Context"
export ENV=development
export DB_NAME=$(jq -r ".$ENV.database" server/config/config.json)
export DB_USER=$(jq -r ".$ENV.username" server/config/config.json)
export DB_PASSWORD=$(jq -r ".$ENV.password" server/config/config.json)
export DB_HOST=$(jq -r ".$ENV.host" server/config/config.json)
export DB_PORT=$(jq -r ".$ENV.port" server/config/config.json)

echo "Init Database"
sed -i "s/{{ DB_NAME }}/$DB_NAME/g" server/config/init-db.sql
mysql -h $DB_HOST -P $DB_PORT -u $DB_USER -p${DB_PASSWORD} < server/config/init-db.sql
sed -i "s/$DB_NAME/{{ DB_NAME }}/g" server/config/init-db.sql
