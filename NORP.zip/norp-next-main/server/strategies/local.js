
const localStrategy = require('passport-local');
const passport = require('passport');
const validatePassword = require('../utils/encrypt').validatePassword;

const db = require("../models");
const User = db.user;

passport.use(new localStrategy({ passReqToCallback: true},
    async (req, username, password, done) => {
        try {
            const user = await User.findOne({where: {username: username}});
            if (user == undefined || user == null) {
                // console.log("User not found")
                done(null, false);
            } else {
                // console.log("User found.")
                if (validatePassword(password, user.hash, user.salt)) {
                    user.last_login = Date.now();
                    // console.log("User is successfully authenticated.")
                    done(null, user);
                } else {
                    // console.log('Bad Credentials. Incorrect Password.');
                    done(null, false);
                }

            }
        } catch (err) {
            done(err, false);
        }
    }
));