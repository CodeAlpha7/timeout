import { useRouter, NextRouter } from "next/router";
import { useEffect, useState } from "react";
import Link from 'next/link';
import styles from '../../styles/NavBar.module.css';
import LoginIcon from '@mui/icons-material/Login';
import Button from '@mui/material/Button';
import logo from '../../../public/images/NORP-Logo.png';
import Image from "next/image";

import axios, { AxiosError } from "axios";



const navigationRoutes = ["home", "people", "contact", "resources"];
const unauthedNavigationRouted = ["login"]
const authedNavigationRoutes = ["metabase", "logout"]


const NavigationLink = ({href, text, router}: {href: string, text: string, router: NextRouter}) => {
    const isActive = router.asPath === (href === "/home" ? "/" : href );
    return (
        href === "/login" ?
        <Link href={href} passHref>
            <Button
                variant="outlined"
                startIcon={<LoginIcon />}
                onClick={(e) => {

                }}
            >
                Login
            </Button> 
        </Link>:
        <Link href={href === "/home" ? "/" : href} passHref>
            <a
                href={href === "/home" ? "/" : href}
                className={`${isActive && `${styles.nav_item_active}`} ${styles.nav_item}`}>
                    {text}
            </a>
        </Link>
    );
}


interface UserResponse {
    user: string | null;
    error: AxiosError | null;
  }

async function getUser(): Promise<UserResponse> {
    try {
      const { data } = await axios.get("/authuser");
  
      return {
        user: data,
        error: null,
      };
    } catch (e) {
      const error = e as AxiosError;
  
      return {
        user: null,
        error,
      };
    }
  }



const NavBar = () => {
    const router = useRouter();
    const [authenticated, setAuthenticated] = useState(false);

    const { push } = useRouter();

    useEffect(() => {
        (async () => {
          const { user, error } = await getUser();
          if (error) {
            return;
          }
          // if the error did not happen, if everything is alright
          setAuthenticated(true);
        })();
      }, [push]);

    if(authenticated){
        return (
            <nav className={styles.nav_container}>
                <Image src={logo} width="300" height="65"></Image>
                <div className={styles.nav_item_container}>
                    {
                        navigationRoutes.map( (route: string) => {
                            return(
                                <NavigationLink
                                key={route}
                                href={`/${route}`}
                                text={route.toUpperCase()}
                                router={router}
                                />
                                );
                        })
                    }
                    {
                        authedNavigationRoutes.map( (route: string) => {
                            return(
                                <NavigationLink
                                key={route}
                                href={`/${route}`}
                                text={route.toUpperCase()}
                                router={router}
                                />
                                );
                        })
                    }
                </div>
            </nav>
        );
    }
    else{
        return (
            <nav className={styles.nav_container}>
                <Image src={logo} width="300" height="65"></Image>
                <div className={styles.nav_item_container}>
                    {
                        navigationRoutes.map( (route: string) => {
                            return(
                                <NavigationLink
                                key={route}
                                href={`/${route}`}
                                text={route.toUpperCase()}
                                router={router}
                                />
                            );
                        })
                    }
                    {
                        unauthedNavigationRouted.map( (route: string) => {
                            return(
                                <NavigationLink
                                key={route}
                                href={`/${route}`}
                                text={route.toUpperCase()}
                                router={router}
                                />
                            );
                        })
                    }
                </div>
            </nav>
        );
    }
}

export { NavBar };