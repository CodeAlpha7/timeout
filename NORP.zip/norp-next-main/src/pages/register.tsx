import { useState } from 'react';
import type { NextPage } from 'next';
import Link from "next/link";
import styles from '../styles/Register.module.css';
import { useRouter } from 'next/router';
import { CardContent,
  FormControl,
  InputLabel,
  OutlinedInput,
  InputAdornment,
  Container,
  Divider,
  IconButton,
  Button,
  Card,
  Box } from '@mui/material';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import isEmail from 'validator/lib/isEmail';

interface IRegistrationInfo {
    firstName: string,
    lastName: string,
    email: string,
    password: string
}

const registerUser = async (registrationInfo: IRegistrationInfo) => {
    var requestHeaders = new Headers();
    requestHeaders.append("Content-Type", "application/json");
    const { firstName, lastName, email, password } = registrationInfo;
    const requestData = {
        first_name: firstName,
        last_name: lastName,
        username: email,
        password: password
    };
  
    const response = await fetch(`/reg`, {
        method: 'POST',
        body: JSON.stringify(requestData),
        redirect: 'follow',
        headers: requestHeaders
      });
      let responseData;
      if (response.status === 201) {
        alert("Registration Successful!")
        responseData = await response.json();
      }
      if(response.status === 401){
        responseData = await response.json();
        alert("Registration Failed!\n"+responseData.status)
      }
      return responseData;
}

function isEmailValid(email: string) {
    return isEmail(email);
}

function registerContent() {
    const [showPassword, setShowPassword] = useState(false);

    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [isEmailDirty, setIsEmailDirty] = useState(false);
    const [password, setPassword] = useState("");

    return (
        <CardContent>
            <Container sx={{paddingBottom:"5%"}}>
                <FormControl variant="outlined" sx={{ m: 1, width: '25ch' }}>
                    <InputLabel required>First Name</InputLabel>
                    <OutlinedInput
                        id="outlined-adornment-firstname"
                        type={""}
                        onChange={(e) => {
                            setFirstName(e.target.value);
                        }}
                        label="First Name"
                    />
                </FormControl>
                <FormControl variant="outlined" sx={{ m: 1, width: '25ch' }}>
                    <InputLabel required>Last Name</InputLabel>
                    <OutlinedInput
                        id="outlined-adornment-lastname"
                        type={""}
                        onChange={(e) => {
                            setLastName(e.target.value);
                        }}
                        label="Last Name"
                    />
                </FormControl>
            </Container>
            <Container sx={{paddingBottom:"5%"}}>
                <FormControl variant="outlined" sx={{ m: 1, width: '25ch' }}>
                    <InputLabel required>Email</InputLabel>
                    <OutlinedInput
                        id="outlined-adornment-email"
                        type={""}
                        onChange={(e) => {
                            setEmail(e.target.value);
                            setIsEmailDirty(true);
                        }}
                        error={isEmailDirty && !isEmailValid(email)}
                        label="Email"
                    />
                </FormControl>
                <FormControl variant="outlined" sx={{ m: 1, width: '25ch' }}>
                    <InputLabel required>Password</InputLabel>
                    <OutlinedInput
                            id="outlined-adornment-password"
                            type={showPassword ? "text" : "password"}
                            onChange={(e) => {
                            setPassword(e.target.value);
                        }}
                        endAdornment={
                        <InputAdornment position="end">
                            <IconButton
                            aria-label="toggle password visibility"
                            onClick={(e) => {
                                setShowPassword(!showPassword);
                            }}
                            onMouseDown={() => {}}
                            edge="end"
                            >
                            {showPassword ? <Visibility />:<VisibilityOff />}
                            </IconButton>
                        </InputAdornment>
                        }
                        label="Password"
                    />
                </FormControl>
            </Container>
            <Container sx={{direction:"column", alignItems:"center", justifyContent:"center", display:"flex", flexDirection:"column"}}>
                <Button variant="outlined" size="medium" onClick={async (e) => {
                    const registrationInfo: IRegistrationInfo = {
                        firstName,
                        lastName,
                        email,
                        password
                    }
                    registerUser(registrationInfo);
                }}> Register </Button>
            </Container>
        </CardContent>
    );
}

function Register() {
    return (
        <div>
        <div className={styles.container}>
        <Box sx={{ display: "flex", justifyContent: "center", alignSelf: "center", height: "100%"}}>
          <Card variant="outlined" sx={{ marginTop: "7%", marginBottom: "7%"}}>{registerContent()}</Card>
        </Box>
      </div>
      </div>
    );
}

export default Register;