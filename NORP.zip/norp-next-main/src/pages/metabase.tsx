import type { NextPage } from 'next';
import * as React from "react";
import styles from '../styles/Metabase.module.css';
import Link from 'next/link';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Button from '@mui/material/Button';
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import Image from 'next/image'
import pub78 from './/images/pub78.png';
import query1 from './/images/query1.png';
import query2 from './/images/query2.png';
import census1 from './/images/census1.png';
import analytics1 from './/images/analytics1.png'
import analytics2 from './/images/analytics2.png'
import bmf1 from './/images/bmf1.png'
import bmf2 from './/images/bmf2.png'
import public_survey_1 from './/images/public_survey_1.png'
import public_survey_2 from './/images/public_survey_2.png';
import { NCCSDashboard } from '../components/MetabaseDashboards/NCCSDashboard';
import axios, { AxiosError } from "axios";
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';

/**
 *
 * @returns Metabase page
 *
 */

interface UserResponse {
  user: string | null;
  error: AxiosError | null;
}

async function getUser(): Promise<UserResponse> {
  try {
    const { data } = await axios.get("/authuser");

    return {
      user: data,
      error: null,
    };
  } catch (e) {
    const error = e as AxiosError;

    return {
      user: null,
      error,
    };
  }
}


const Metabase: NextPage = () => {
  const [value, setValue] = React.useState("1");
  const [authenticated, setAuthenticated] = useState(false);

  const { push } = useRouter();

  useEffect(() => {
      (async () => {
        const { user, error } = await getUser();
        if (error) {
          return;
        }
        // if the error did not happen, if everything is alright
        setAuthenticated(true);
      })();
    }, [push]);


  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };
  const METABASE_SITE_URL = process.env.METABASE_SITE_URL;

  if(authenticated){
    return (
      <div className={styles.container}>
        <Box sx={{ width: "100%", typography: "body1" }}>
        <TabContext value={value}>
          <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
            <TabList onChange={handleChange}>
              <Tab label="Metabase" value="1" data-test='Metabase-tab'/>
              <Tab label="NCCS" value="2" data-test='NCCS-tab'/>
              <Tab label="NCCS Dashboard" value="3" data-test='NCCS-Dashboard-tab'/>
            </TabList>
          </Box>
          <TabPanel value="1">
            <Box textAlign='center'>
              <Button href={`${METABASE_SITE_URL}`} target="_blank" rel="noopener noreferrer" variant='contained' size="large">
                Metabase Login
              </Button>
            </Box>
            <Box sx={{ width: '100%', p:5}} alignItems="center">
              <Typography variant="h6" color="text.main">
                Metabase is an open-source business intelligence tool that lets you ask questions about your data and displays the data in any format such as bar chart and detailed table. Some capabilities include query builder to filter and summarize data, ask questions and visualize them, create customized dashboards, among others.
                <Link href="https://www.metabase.com/product/" passHref >
                  <a target="_blank" rel="noopener noreferrer"> More info </a>
                </Link>
              </Typography>
            </Box>
            <Accordion>
                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                  <Typography variant="h6" color="text.main">Analytics</Typography>
                </AccordionSummary>
                <AccordionDetails>
                <Typography variant="h6" color="text.main">
                  In Metabase we use SQL to process and visualize trends in non-profit organizations. Some examples including their queries are:
                </Typography>
                <Typography variant="subtitle1" color="text.main">
                 - Average Nonprofit Expenses by State
                </Typography>
                <Stack direction="column"
                  justifyContent="center"
                  alignItems="flex-start"
                  spacing={2}>
                  <Image src={query1} width="600" height="80" alt="one2"></Image>
                  <Image src={analytics1} alt="one1" width="700" height="300"></Image>
                </Stack>
                <Typography variant="subtitle1" color="text.main">
                 - NCCS Group by NTEE
                </Typography>
                <Stack direction="column"
                  justifyContent="center"
                  alignItems="flex-start"
                  spacing={2}>
                  <Image src={query2} width="600" height="200" alt="one2"></Image>
                  <Image src={analytics2} width="700" height="300" alt="one2"></Image>
                </Stack>
                </AccordionDetails>
              </Accordion>
          </TabPanel>
          <TabPanel value="2">
             {/* Tables for database NCCS */}
             <Box sx={{ width: '100%', p:5}} alignItems="center">
             <Typography variant="h6" color="text.main">
                  National Center for Charitable Statistics Data Archive (NCCS) produces data intended for use by researchers and policy-makers in their quantitative analysis, and as a sporingboard for more in-depth survey or case study search. Some tables in their database are:
              </Typography>
             </Box>
             <Accordion>
                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                  <Typography variant="h6" color="text.main">Pub78</Typography>
                </AccordionSummary>
                <AccordionDetails>
                <Typography variant="body1" color="text.main">
                  List of organizations eligible to receive tax-deductible charitable contributions
                </Typography>
                <Image src={pub78} width="500" height="300"></Image>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                  <Typography variant="h6" color="text.main">BMF (Business Master File)</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography variant="body1" color="text.main">
                    The Exempt Organizations Business Master File Extract provides information about an organization from the Internal Revenue Service’s Business Master File. They are divided by states and regions
                  </Typography>
                  <Image src={bmf1} width="800" height="300"></Image>
                  <Image src={bmf2} width="600" height="300"></Image>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                  <Typography variant="h6" color="text.main">Census</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography variant="body1" color="text.main">
                    A census is the complete enumeration of a population or groups at a point in time with respect to well defined characteristics: for example, population, production, traffic on particular roads
                  </Typography>
                  <Image src={census1} width="800" height="300"></Image>
                </AccordionDetails>
              </Accordion>
              <Accordion>
                <AccordionSummary expandIcon={<ExpandMoreIcon />}>
                  <Typography variant="h6" color="text.main">Survey Public 2021</Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography variant="body1" color="text.main">
                    National Survey of Nonprofit Trends and Impacts Public Use Files. The pring 2021 survey was the first wave of a panel dataset designed to collect repeat observations that will help policymakers, nonprofits, and researchers better understand the long-term experiences of 501(c)(3) nonprofit organizations in the US. Additional datasets will be posted as future survey waves are fielded
                  </Typography>
                  <Image src={public_survey_1} width="700" height="300"></Image>
                  <Image src={public_survey_2} width="700" height="300"></Image>
                </AccordionDetails>
              </Accordion>
          </TabPanel>
          <TabPanel value='3'>
            <NCCSDashboard/>
          </TabPanel>
        </TabContext>
      </Box>
    </div>
    )
  }
  else{
    return (
      <div className={styles.container}>
        <Box sx={{ width: "100%", typography: "h2"}} alignItems="center" display="flex" justifyContent = "center" >
          Please login to view this page
        </Box>
      </div>
    )
  }
}

export default Metabase