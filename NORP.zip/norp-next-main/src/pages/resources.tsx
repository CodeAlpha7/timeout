import React from 'react';
import { useState } from 'react';
import type { NextPage } from 'next';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import styles from '../styles/Resources.module.css';

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    padding: theme.spacing(4),
  },
  card: {
    margin: theme.spacing(2),
  },
  title: {
    fontWeight: 'bold',
    marginBottom: theme.spacing(2),
  },
  description: {
    color: theme.palette.text.secondary,
    marginBottom: theme.spacing(2),
  },
  descriptionMarging: {
    color: theme.palette.text.secondary,
    marginBottom: theme.spacing(2),
    marginTop: theme.spacing(4),
    marginRight: theme.spacing(6),
    marginLeft: theme.spacing(6),
  },
}));

const RESOURCES = [
  {
    category: 'Data Analytics',
    items: [
      {
        title: 'SQL for NCCS',
        description: 'Walkthrough of SQL queries relevant to National Center for Charitable Statistics Data Archive (NCCS) data',
        videoLink: 'https://www.youtube.com/watch?v=wv2XhjsHn2k'
      },
      {
        title: 'Census Data Analytics',
        description: 'Analysis of census data using statistical software',
        videoLink: 'https://www.youtube.com/watch?v=BUfw-GVS8O0'
      },
      {
        title: 'NORP Class Presentation',
        description: 'Slides from NORP class presentation on data analytics',
        videoLink: 'https://www.youtube.com/watch?v=xtf5TDxBcLs'
      },
    ],
  },
  {
    category: 'Metabase',
    items: [
      {
        title: 'Metabase Visualization',
        description: 'Guide to creating visualizations in Metabase',
        videoLink: 'https://www.youtube.com/watch?v=t9h2OhKuVi8'
      },
      {
        title: 'Metabase Functionalities',
        description: 'Overview of Metabase features and capabilities',
        videoLink: 'https://www.youtube.com/watch?v=lBOhlNmgzKU'
      },
    ],
  },
  {
    category: 'SQL',
    items: [
      {
        title: 'SQL Walkthrough',
        description: 'Step-by-step guide to writing SQL queries',
        videoLink: 'https://www.youtube.com/watch?v=jbixOn2sPm0'
      },
    ],
  },
];

const Resources: NextPage = () => {
  const classes = useStyles();
  const [searchQuery, setSearchQuery] = useState('');
  const handleFeedbackClick = () => {
    window.open('https://forms.gle/fFBXiRc1byAHwVU19', '_blank');
  };

  const filteredResources = RESOURCES.filter((category) => {
    return category.items.some((item) => {
      return item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
             item.description.toLowerCase().includes(searchQuery.toLowerCase());
    });
  });

  return (
    <div className={styles.container}>
      <Typography variant="h4" className={classes.descriptionMarging} style={{ color: "#1b2c58", textAlign: "center"}}>
          Welcome to our resources page! 
          Here you can find helpful guides, tutorials, and other materials related to data analytics, Metabase, and SQL. Browse the categories below to find what you're looking for.
      </Typography>
      <div style={{ display: 'flex', justifyContent: 'center', margin: '12px 0' }}>
        <input
          type="text"
          placeholder="Search"
          value={searchQuery}
          style={{ marginRight: '8px' }}
          onChange={(event) => setSearchQuery(event.target.value)}
        />
      </div>
      <div style={{ display: 'flex', justifyContent: 'center'}}>
        <button onClick={handleFeedbackClick}>Give Feedback</button>
      </div>
      {filteredResources.map((category) => (
        <div key={category.category}>
          <Typography variant="h5" className={classes.title}>
            {category.category}
          </Typography>
          <Grid container spacing={2}>
            {category.items.map((item) => (
              <Grid item xs={12} sm={6} md={4} key={item.title}>
                <Card className={classes.card}>
                  <CardContent>
                    <Typography variant="h6" className={classes.title}>
                      {item.title}
                    </Typography>
                    <Typography variant="body2" className={classes.description}>
                      {item.description}
                    </Typography>
                    {item.videoLink && (
                      <div className={classes.description}>
                        <iframe 
                          title={item.title} 
                          width="100%" 
                          height="315" 
                          src={item.videoLink.replace('watch?v=', 'embed/')}
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                          allowFullScreen
                        />
                      </div>
                    )}
                  </CardContent>
                </Card>
              </Grid>
            ))}
            {/* Add empty cards to reach 7 boxes */}
            {category.items.length < 7 && (
              [...Array(7 - category.items.length)].map((_, index) => (
                <Grid item xs={12} sm={6} md={4} key={index} />
              ))
            )}
          </Grid>
        </div>
      ))}
    </div>
  );
};



export default Resources;
