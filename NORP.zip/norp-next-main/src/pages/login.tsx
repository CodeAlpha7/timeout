import { useState } from 'react';
import type { NextPage } from 'next';
import Link from "next/link";
import styles from '../styles/Login.module.css';
import { useRouter } from 'next/router';
import { CardContent,
  FormControl,
  InputLabel,
  OutlinedInput,
  InputAdornment,
  Container,
  Divider,
  IconButton,
  Button,
  Card,
  Box 
} from '@mui/material';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
/**
 * 
 * @returns Login page
 * 
*/

const loginUser = async (loginCredentials: any) => {
  var requestHeaders = new Headers();
  requestHeaders.append("Content-Type", "application/json");

  const response = await fetch(`/login`, {
      method: 'POST',
      body: JSON.stringify(loginCredentials),
      redirect: 'follow',
      headers: requestHeaders
    });
    let responseData;
    if (response.status === 200) {
      responseData = await response.json();
    }
    if(response.status === 401){
      alert("Incorrect Username or Password")
    }
    return responseData;
}

const loginContent = (router: any) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const [showPassword, setShowPassword] = useState(false);

  return (
  <>
  <CardContent>
    <Container>
      <FormControl sx={{ m: 1, width: '25ch' }} variant="outlined">
        <InputLabel>Username</InputLabel>
          <OutlinedInput
            id="outlined-adornment-username"
            type={""}
            onChange={(e) => {
              setUsername(e.target.value);
            }}
            label="Username"
          />
      </FormControl>
    </Container>

    <Container sx={{paddingBottom:"5%"}}>
      <FormControl sx={{ m: 1, width: '25ch' }} variant="outlined">
          <InputLabel>Password</InputLabel>
          <OutlinedInput
            id="outlined-adornment-password"
            type={showPassword ? "text" : "password"}
            onChange={(e) => {
              setPassword(e.target.value);
            }}
            endAdornment={
              <InputAdornment position="end">
                <IconButton
                  aria-label="toggle password visibility"
                  onClick={(e) => {
                    setShowPassword(!showPassword);
                  }}
                  onMouseDown={() => {}}
                  edge="end"
                >
                  {showPassword ? <Visibility />:<VisibilityOff />}
                </IconButton>
              </InputAdornment>
            }
            label="Password"
          />
        </FormControl>
    </Container>
    <Container sx={{direction:"column", alignItems:"center", justifyContent:"center", display:"flex", flexDirection:"column", marginBottom:"10%"}}>
      <Button variant="outlined" size="medium" onClick={async (e) => {
        const responseData = await loginUser({
          username,
          password
        });
        if (responseData) {
          router.push('/');
        }
      }}> Login </Button>
    </Container>
    <Divider />

    <Container sx={{direction:"column", alignItems:"center", justifyContent:"center", display:"flex", flexDirection:"column", paddingTop:"5%"}}>
      <Link href="/"><a onClick={(e) => {
        e.preventDefault();
        router.push('/auth/google');
      }}>Login with Google</a></Link>
      or
      <Link href="/register">Register</Link>
    </Container>
  </CardContent>
  </>
)};
const Login: NextPage = () => {
  const router = useRouter();
  return (
    <div>
      <div className={styles.container}>
      <Box sx={{ display: "flex", justifyContent: "center", alignSelf: "center", height: "100%"}}>
        <Card variant="outlined" sx={{ marginTop: "7%", marginBottom: "7%"}}>{loginContent(router)}</Card>
      </Box>
    </div>
    </div>
  )
}

export default Login