import type { NextPage } from 'next';
import styles from '../styles/About.module.css';

/**
 * 
 * @returns About page
 * 
 */
const About: NextPage = () => {
  return (
    <div className={styles.container}>
    </div>
  )
}

export default About
