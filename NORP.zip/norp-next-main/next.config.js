/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  env: {
    METABASE_SECRET_KEY: process.env.METABASE_SECRET_KEY,
    METABASE_SITE_URL: process.env.METABASE_SITE_URL
  },
}

module.exports = nextConfig
