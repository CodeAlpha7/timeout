describe('people page', () => {
    beforeEach(() => {
        cy.visit('/')
        cy.get('.NavBar_nav_item_container__80XW_ > [href="/people"]').click()
    })

    it('should go to people page and see Calton Pu', () => {
        cy.get(':nth-child(1) > .MuiPaper-root > .MuiCardContent-root > .MuiTypography-h5').contains('Calton Pu')
    }) 
})