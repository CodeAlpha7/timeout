describe('login page', () => {
    beforeEach(() => {
        cy.visit('/')
        cy.get('.NavBar_nav_item_container__80XW_ > .MuiButtonBase-root').click()
    })
    
    it('should go to login page and enter the Username and Password', () => {
        cy.get('#outlined-adornment-username').type('user@email.com')
        cy.get('#outlined-adornment-password').type('testPASSWORD123')
        cy.get('.mui-style-1katgof-MuiContainer-root > .MuiButtonBase-root').contains('Login').click()
        cy.get('.mui-style-10e8m8e-MuiContainer-root > .MuiButtonBase-root').contains('Login with Google').click()
    })
})