describe('contact page', () => {
    beforeEach(() => {
        cy.visit('/')
        cy.get('[href="/contact"]').click()
    })

    it('should go to Contact page and see a submit botton', () => {
        cy.get('.mui-style-2w9i69-MuiContainer-root > :nth-child(1) > #standard-required-label').contains('FIRST NAME')
        cy.get('.mui-style-2w9i69-MuiContainer-root > :nth-child(1) > .MuiInputBase-root > #standard-required').type('John')
        
        cy.get('.mui-style-2w9i69-MuiContainer-root > :nth-child(2) > #standard-required-label').contains('LAST NAME')
        cy.get('.mui-style-2w9i69-MuiContainer-root > :nth-child(2) > .MuiInputBase-root > #standard-required').type('Doe')

        cy.get('.mui-style-1n04t26-MuiContainer-root > :nth-child(1) > #standard-required-label').contains('EMAIL')
        cy.get('.mui-style-1n04t26-MuiContainer-root > :nth-child(1) > .MuiInputBase-root > #standard-required').type('user@emial.com')

        cy.get('.mui-style-1n04t26-MuiContainer-root > :nth-child(2) > #standard-required-label').contains('PHONE NUMBER')
        cy.get('.mui-style-1n04t26-MuiContainer-root > :nth-child(2) > .MuiInputBase-root > #standard-required').type('6461111111')

        cy.get('.mui-style-15ausey-MuiContainer-root > .MuiFormControl-root > #standard-required-label').contains('WRITE YOUR MESSAGE HERE')
        cy.get('.mui-style-15ausey-MuiContainer-root > .MuiFormControl-root > .MuiInputBase-root > #standard-required').type('This is a test!')
        cy.get('.mui-style-15ausey-MuiContainer-root > .MuiButtonBase-root').contains('Submit').click()
    })
})