describe('resources page', () => {
    beforeEach(() => {
        cy.visit('/')
        cy.get('[href="/resources"]').click()
    })
    
    it('should go to resources page', () => {
        // the page is empty at this moment
    })
})