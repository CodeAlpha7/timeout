describe('home page', () => {
  beforeEach(() => {
    cy.visit('/')
  })

  it('should go to home page and see about NORP', () => {
    cy.get('.MuiTypography-h2').contains('About NORP')
  })

  it('should go to People page by clicking SEE WHO WE ARE button', () => {
    cy.get('.Home_btn_container__aDZVk > .MuiButtonBase-root').contains('See who we are')
    cy.get('.Home_btn_container__aDZVk > .MuiButtonBase-root').click()
    cy.get('.MuiTypography-h2').contains('Meet the team')
  })

  it('should go to Resources page by clicking Resources block', () => {
    cy.get(':nth-child(1) > .MuiPaper-root > .MuiButtonBase-root > .MuiCardContent-root').contains('Resources').click()
  })

  it('should go to Metabase page by clicking Metabase block', () => {
    cy.get(':nth-child(2) > .MuiPaper-root > .MuiButtonBase-root').contains('Metabase').click()
    cy.get('.mui-style-xi606m').contains('Metabase Login')
  })

  it('should go to Contact page by clicking Contact block', () => {
    cy.get(':nth-child(3) > .MuiPaper-root > .MuiButtonBase-root > .MuiCardContent-root').contains('Contact').click()
    cy.get('.MuiTypography-h4').contains('STAY UPDATED')
  })

  it('should go to login page by clicking LOGIN', () => {
    cy.get('.NavBar_nav_item_container__80XW_ > .MuiButtonBase-root').contains('Login').click()
    cy.get('.mui-style-1katgof-MuiContainer-root > .MuiButtonBase-root').contains('Login')
  })
})