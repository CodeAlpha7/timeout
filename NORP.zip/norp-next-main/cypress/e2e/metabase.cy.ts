describe('metabase page', () => {
    beforeEach(() => {
        cy.visit('/')
        cy.get('[href="/metabase"]').click()
    })

    it('should go to matabse tab and see anlytices', () => {
        cy.get('[role=tablist] > [data-test=Metabase-tab]').click()
        cy.get('.MuiPaper-root > .MuiButtonBase-root').contains('Analytics').click()
    })

    it('should go to NCCS tab', () => {
        cy.get('[role=tablist] > [data-test=NCCS-tab]').click()
    })

    it('should go to NCCS Dashboard tab', () => {
        cy.get('[role=tablist] > [data-test=NCCS-Dashboard-tab]').click()
        cy.get('iframe')
    })

})